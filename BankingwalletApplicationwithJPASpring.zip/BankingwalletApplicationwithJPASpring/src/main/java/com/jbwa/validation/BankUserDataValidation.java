package com.jbwa.validation;

import com.jbwa.Exception.BankUserDataInvalidException;
import com.jbwa.dao.BankDAOImpl;

public class BankUserDataValidation {

	static BankDAOImpl bankDAO;
	
	public static boolean checkName(String name) throws BankUserDataInvalidException{
		
		int n = name.length();
		char[] ch = name.toCharArray();
		for (int i = 0; i < n; i++) {
			try {
				if (ch[i] > 64 && ch[i] < 122 && ch[0]>63 && ch[0]<90) {
					return true;
				} else {
					throw new BankUserDataInvalidException("Invalid Name");
				}
			} 
			catch (BankUserDataInvalidException E) {
				System.out.println(E);
				return false;
			}
	}
		return false;
	}
	
	
	public static boolean checkPhoneNumber(String number) throws BankUserDataInvalidException
	{
		try {
			if (number.matches("[0-9]+") && number.length() == 10) {
				return true;
			} else {
				throw new BankUserDataInvalidException("Invalid Phonenumber");
			}
		} catch (BankUserDataInvalidException e) {
			return false;
		}
	}
	
	public static boolean checkAccNo(int accountNumber)
	{
		if(bankDAO.checkAccNo(accountNumber))
			return true;
			else
			{
				System.out.println("INVALID ACCOUNT NUMBER");
			return false;
			}
     }
	
}
