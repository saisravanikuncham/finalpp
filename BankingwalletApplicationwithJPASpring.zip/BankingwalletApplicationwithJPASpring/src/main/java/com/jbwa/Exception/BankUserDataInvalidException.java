package com.jbwa.Exception;

public class BankUserDataInvalidException extends Exception {

	String s1;

	public BankUserDataInvalidException(String s) {
		s1 = s;

	}

	public String toString() {
		return (s1);
	}

	
}
