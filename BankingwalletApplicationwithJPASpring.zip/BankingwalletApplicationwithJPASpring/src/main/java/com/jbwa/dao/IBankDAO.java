package com.jbwa.dao;

import java.util.List;

import com.jbwa.pojo.BankPojo;
import com.jbwa.pojo.TransactionPojo;

public interface IBankDAO {
	public void addUserAccount(BankPojo bank);
	
	public BankPojo getBalance(int accountNo);
	
	public BankPojo depositMoney(int accountNumber,long amount,TransactionPojo tran);
	
	public BankPojo withdrawMoney(int accountNumber, long amount,TransactionPojo tran);
	
	public List<TransactionPojo> getTransaction(int accountNumber);

	public BankPojo transferMoney(int accountNumber01, long amount01, int accountNumber02,TransactionPojo tran1,TransactionPojo tran2);
}
