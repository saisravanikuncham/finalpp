package com.jbwa.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.jbwa.pojo.BankPojo;
import com.jbwa.pojo.TransactionPojo;

@Repository("bankDAO")
@Transactional
public class BankDAOImpl implements IBankDAO {

	@PersistenceContext
	private EntityManager entityManager;

	BankPojo bank;

	TransactionPojo transactionPojo;

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public void addUserAccount(BankPojo bank) {
		entityManager.persist(bank);
	}

	public BankPojo getBalance(int accountNo) {
		// TODO Auto-generated method stub
		bank = entityManager.find(BankPojo.class, accountNo);
		return bank;
	}

	public BankPojo depositMoney(int accountNumber, long amount, TransactionPojo tran) {
		bank = entityManager.find(BankPojo.class, accountNumber);
		bank.setBalance(bank.getBalance() + amount);
		entityManager.persist(bank);
		entityManager.persist(tran);
		return bank;
	}

	public BankPojo withdrawMoney(int accountNumber, long amount, TransactionPojo tran) {
		bank = entityManager.find(BankPojo.class, accountNumber);
		bank.setBalance(bank.getBalance() - amount);
		entityManager.persist(bank);
		entityManager.persist(tran);
		return bank;
	}

	public List<TransactionPojo> getTransaction(int accountNumber) {
		@SuppressWarnings("unchecked")
		TypedQuery<TransactionPojo> query = (TypedQuery<TransactionPojo>) entityManager
				.createQuery("SELECT t FROM TransactionPojo t where acNo = ?1").setParameter(1, accountNumber);
		List<TransactionPojo> transaction = query.getResultList();
		return transaction;
	}

	public BankPojo transferMoney(int accountNumber01, long amount01, int accountNumber02, TransactionPojo tran1,
			TransactionPojo tran2) {

		BankPojo bank1 = entityManager.find(BankPojo.class, accountNumber01);
		bank1.setBalance(bank.getBalance() - amount01);
		entityManager.persist(bank1);
		entityManager.persist(tran1);
		BankPojo bank2 = entityManager.find(BankPojo.class, accountNumber02);
		bank2.setBalance(bank.getBalance() + amount01);
		entityManager.persist(bank2);
		entityManager.persist(tran2);
		return bank;
	}
	/*
	 * checking account
	 */

	
		public boolean checkAccNo(int accountNumber) {
			
			BankPojo bank=(BankPojo)entityManager.find(BankPojo.class, accountNumber);
			
			if(bank!=null)
				return false;
			else {

				System.out.println("123");
				return true;
		}}

}
