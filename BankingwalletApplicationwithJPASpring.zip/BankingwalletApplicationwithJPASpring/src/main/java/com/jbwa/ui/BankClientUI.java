package com.jbwa.ui;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.jbwa.Exception.BankUserDataInvalidException;
import com.jbwa.pojo.BankPojo;
import com.jbwa.pojo.TransactionPojo;
import com.jbwa.service.BankServiceImpl;
import com.jbwa.validation.BankUserDataValidation;

public class BankClientUI {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		BankPojo bankPojo;
		TransactionPojo tran;
		@SuppressWarnings("resource")
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		BankServiceImpl bankService = context.getBean("bankService", BankServiceImpl.class);
		int choice;
		while (true) {
			System.out.println("Welcome to xyz bank wallet");
			System.out.println("Choose any of these options from one to seven");
			System.out.println("1.Create an Account");
			System.out.println("2.Check your Balance");
			System.out.println("3.Deposit Money");
			System.out.println("4.Withdraw Money");
			System.out.println("5.Transfer Money");
			System.out.println("6.View Transaction");
			System.out.println("7.Exit");
			choice = scanner.nextInt();
			switch (choice) {
			case 1:
				System.out.println("ENTER YOUR NAME:");
				String name = scanner.next();
				try {
					while (!BankUserDataValidation.checkName(name)) {
						System.out.print("    Enter your name : ");
						name = scanner.next();
						name += scanner.nextLine();
					}
				} catch (BankUserDataInvalidException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("ENTER YOUR DATE OF BIRTH IN DD/MM/YYYY");
				String dob = scanner.next();
				System.out.println("ENTER YOUR PHONE NUMBER ( MUST CONTAIN ONLY TEN DIGITS )");
				String phno = scanner.next();
				try {
					while (!BankUserDataValidation.checkPhoneNumber(phno)) {
						System.out.print("Enter your phone number : ");
						phno = scanner.next();
					}
				} catch (BankUserDataInvalidException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("ENTER THE AMOUNT YOU WANT TO DEPOSIT");
				long amt = scanner.nextLong();
				int acno = (int) ((Math.random()) * 100000000);
				bankPojo = new BankPojo(acno, name, dob, phno, amt);
				bankService.addAccount(bankPojo);
				System.out.println("Account Crated Successfully. " + name + " your account number is " + acno);
				break;

			case 2:
				System.out.println("ENTER YOUR ACCOUNT NUMBER : ");
				int accountNumber = scanner.nextInt();
//				while(!BankUserDataValidation.checkAccNo(accountNumber))					//validating account number
//            	{
//                	 System.out.print("Enter your account number : ");
//                	 accountNumber=scanner.nextInt();
//            	}
				bankPojo = bankService.checkBalance(accountNumber);
				System.out
						.println("Hello " + bankPojo.getName() + ". Your Account balance is " + bankPojo.getBalance());
				break;

			case 3:
				System.out.println("ENTER YOUR ACCOUNT NUMBER : ");
				int accountNumber1 = scanner.nextInt();

				System.out.println("ENTER THE AMOUNT YOU NEED TO DEPOSIT : ");
				long amount = scanner.nextLong();
				int tid = (int) ((Math.random()) * 100000);
				tran = new TransactionPojo(tid, accountNumber1, "Date : " + LocalDate.now() + " Time : "
						+ LocalTime.now() + " Rs." + amount + "Deposited Successfuly");
				bankPojo = bankService.depositMoney(accountNumber1, amount, tran);
				System.out.println("Hello " + bankPojo.getName() + "." + amount + " Deposited successfully");
				break;

			case 4:
				System.out.println("ENTER YOUR ACCOUNT NUMBER : ");
				int accountNumberr = scanner.nextInt();

				System.out.println("ENTER THE AMOUNT YOU NEED TO Withdraw : ");
				long amountt = scanner.nextLong();
				int tidd = (int) ((Math.random()) * 100000);
				tran = new TransactionPojo(tidd, accountNumberr, "Date : " + LocalDate.now() + " Time : "
						+ LocalTime.now() + " Rs." + amountt + "Withdrawn Successfuly");
				bankPojo = bankService.withdrawMoney(accountNumberr, amountt, tran);
				System.out.println("Hello " + bankPojo.getName() + "." + amountt + " withdrawn successfully");
				break;

			case 5:
				System.out.println("ENTER YOUR ACCOUNT NUMBER : ");
				int accountNumber01 = scanner.nextInt();

				System.out.println("ENTER THE AMOUNT YOU NEED TO Transfer : ");
				long amount01 = scanner.nextLong();
				System.out.println("ENTER YOUR ACCOUNT NUMBER : ");
				int accountNumber02 = scanner.nextInt();

				int ttid1 = (int) ((Math.random()) * 100000);
				int ttid2 = (int) ((Math.random()) * 100000);
				TransactionPojo tran1 = new TransactionPojo(ttid1, accountNumber01, "Date : " + LocalDate.now()
						+ " Time : " + LocalTime.now() + " Rs." + amount01 + "Sent Successfuly");
				TransactionPojo tran2 = new TransactionPojo(ttid2, accountNumber02, "Date : " + LocalDate.now()
						+ " Time : " + LocalTime.now() + " Rs." + amount01 + "Received Successfuly");
				bankPojo = bankService.transferMoney(accountNumber01, amount01, accountNumber02, tran1, tran2);
				System.out.println("Hello " + bankPojo.getName() + "." + amount01 + " Sent successfully");
				break;

			case 6:
				System.out.println("ENTER YOUR ACCOUNT NUMBER : ");
				int accountNumber111 = scanner.nextInt();
				// validating account number

				System.out.println("Your Transaction Deatils ");
				System.out.println(bankService.getTransactionDetails(accountNumber111));
				break;

			case 7:
				System.out.println("Thanks for using our services");
				scanner.close();
				System.exit(0);
				break;

			default:
				System.out.println("Enter the choices between 1-7");
			}
		}
	}

}
