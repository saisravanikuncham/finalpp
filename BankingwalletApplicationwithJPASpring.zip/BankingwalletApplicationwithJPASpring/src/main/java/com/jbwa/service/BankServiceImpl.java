package com.jbwa.service;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jbwa.dao.BankDAOImpl;
import com.jbwa.pojo.BankPojo;
import com.jbwa.pojo.TransactionPojo;

@Service("bankService")
public class BankServiceImpl implements IBankService {

	@Autowired
	private BankDAOImpl bankDao;

	public void addAccount(BankPojo bankPojo) {
		bankDao.addUserAccount(bankPojo);
	}

	public BankPojo checkBalance(int accountNo) {
		return bankDao.getBalance(accountNo);
	}

	public BankPojo depositMoney(int accountNumber, long amount, TransactionPojo trans) {
		return bankDao.depositMoney(accountNumber, amount, trans);
	}

	public BankPojo withdrawMoney(int accountNumber, long amount, TransactionPojo tran) {

		return bankDao.withdrawMoney(accountNumber, amount, tran);
	}

	public BankPojo transferMoney(int accountNumber01, long amount01, int accountNumber02, TransactionPojo tran1,
			TransactionPojo tran2) {
		return bankDao.transferMoney(accountNumber01, amount01, accountNumber02, tran1, tran2);
	}

	public String getTransactionDetails(int accountNumber) {
		List<TransactionPojo> hm = bankDao.getTransaction(accountNumber);
		Iterator<TransactionPojo> i = hm.iterator();
		String transactions = "";
		while (i.hasNext()) {
			TransactionPojo trans = (TransactionPojo) i.next();
			transactions = transactions + "\n" + "TransactionID : " + trans.getTranid() + " || AccountNumber : "
					+ trans.getAcNo() + " || TransactionDetails : " + trans.getType();
		}
		return transactions;
	}

}
