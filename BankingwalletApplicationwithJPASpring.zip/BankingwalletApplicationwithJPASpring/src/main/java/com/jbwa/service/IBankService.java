package com.jbwa.service;

import com.jbwa.pojo.BankPojo;
import com.jbwa.pojo.TransactionPojo;

public interface IBankService {
	public void addAccount(BankPojo bankPojo);
	
	public BankPojo checkBalance(int accountNo);
	
	public BankPojo depositMoney(int accountNumber,long amount,TransactionPojo tran);
	
	public BankPojo withdrawMoney(int accountNumber, long amount,TransactionPojo trans);
	
	public String getTransactionDetails(int accountNumber);

	public BankPojo transferMoney(int accountNumber01, long amount01, int accountNumber02,TransactionPojo trans1,TransactionPojo trans2); 
}
