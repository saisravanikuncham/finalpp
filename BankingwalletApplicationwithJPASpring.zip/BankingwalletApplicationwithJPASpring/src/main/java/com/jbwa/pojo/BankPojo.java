package com.jbwa.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Pojo_Bank")
public class BankPojo {

	@Id
	@Column(name="accnum",length=20)
	private int acNo;

	@Column(name="bclient_name")
	private String name;

	@Column(name="bc_dob")
	private String dob;
	
	@Column(name="bc_mobile")
	private String number;
	
	@Column(name="bc_tbalance")
	private long balance;

	public BankPojo(int acNo, String name, String dob, String number, long balance) {
		super();
		this.acNo = acNo;
		this.name = name;
		this.dob = dob;
		this.number = number;
		this.balance = balance;
	}

	public BankPojo() {
	}

	public int getAcNo() {
		return acNo;
	}

	public void setAcNo(int acNo) {
		this.acNo = acNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public long getBalance() {
		return balance;
	}

	public void setBalance(long balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "BankPojo [acNo=" + acNo + ", name=" + name + ", dob=" + dob + ", number=" + number +  ", balance=" + balance + "]";
	}
	
	
	
}
