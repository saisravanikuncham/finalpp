package com.jbwa.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Pojo_Transaction")
public class TransactionPojo {

	@Id
	@Column(name="TransactionID")
	private int tranid;
	@Column(name="AccountNumber")
	private int acNo;
	@Column(name="TransactionType")
	private String type;

	public TransactionPojo(int tranid, int acNo, String type) {
		super();
		this.tranid = tranid;
		this.acNo = acNo;
		this.type = type;
	}

	public TransactionPojo() {
	}

	public int getTranid() {
		return tranid;
	}

	public void setTranid(int tranid) {
		this.tranid = tranid;
	}

	public int getAcNo() {
		return acNo;
	}

	public void setAcNo(int acNo) {
		this.acNo = acNo;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}
