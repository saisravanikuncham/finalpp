package com.cg.restful.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.restful.entity.Customer;
import com.cg.restful.entity.Transaction;
import com.cg.restful.service.BankService;

@RestController
public class BankController {
	@Autowired
	BankService bankService;


	@PostMapping("/createaccount")
	public List<Customer> CreateAccount(@RequestBody Customer customer) {
		return bankService.CreateAccount(customer);
	}
@GetMapping("/showbalance/{accno}")
public float ShowBalance(@PathVariable long accno) {
	return bankService.ShowBalance(accno);
}

@PutMapping("/deposit/{accn}/{amount}")
public Optional<Customer> Deposit(@PathVariable long accn,@PathVariable double amount) {
	return bankService.Deposit(accn,amount);
}
@PutMapping("/withdraw/{accno}/{amount}")
public Optional<Customer> WithDraw(@PathVariable long accno,@PathVariable double amount) {
	return bankService.WithDraw(accno,amount);
}
@PutMapping("/transferfund/{sourceaccno}/{destinationaccno}/{amount}")
public List<Customer> TransferFund(@PathVariable long sourceaccno,@PathVariable long destinationaccno,@PathVariable double amount){
	return bankService.TransferFund(sourceaccno,destinationaccno,amount);
}
@GetMapping("/statement/{accno}")
public List<Transaction> PrintTransaction(@PathVariable long accno){
	return bankService.PrintTransaction(accno);
}
}
