package com.cg.restful.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="CustomerRestFul")
public class Customer {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="AccId")
    @SequenceGenerator(name="AccId", initialValue=1000, allocationSize=1, sequenceName = "customerAccNo")
    @Column(name="CustomerAccNo", updatable=false, nullable=false)
	private long accountNo;
	private String name;
	private long phoneNo;
	private float balance;
	private long aadharNo;
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}
	public float getBalance() {
		return balance;
	}
	public void setBalance(float balance) {
		this.balance = balance;
	}
	public long getAadharNo() {
		return aadharNo;
	}
	public void setAadharNo(long aadharNo) {
		this.aadharNo = aadharNo;
	}
	@Override
	public String toString() {
		return "Customer [accountNo=" + accountNo + ", name=" + name + ", phoneNo=" + phoneNo + ", balance=" + balance
				+ ", aadharNo=" + aadharNo + "]";
	}
}
