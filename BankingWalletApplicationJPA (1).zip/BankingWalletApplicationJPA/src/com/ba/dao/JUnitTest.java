package com.ba.dao;

import static org.junit.jupiter.api.Assertions.*;

import javax.persistence.EntityManager;

import org.junit.Assert;
import org.junit.jupiter.api.Test;

import com.ba.pojo.Bank;

class JUnitTest {

    EntityManager entityManager;
 JPAUtil jUtil=new JPAUtil();
 Bank bank;
	
 @Test
 public void getBalance()
 {
	 entityManager=jUtil.getEntityManager();
	 entityManager.getTransaction().begin();
	 Bank bank=entityManager.find(Bank.class, new Integer(68671));
	 entityManager.getTransaction().commit();
	 long bal=bank.getBalance();
	 long expected=1000;
	 Assert.assertEquals(expected, bal);
 }
}
