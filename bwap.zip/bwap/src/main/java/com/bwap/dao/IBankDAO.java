package com.bwap.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bwap.entity.Bank;
@Repository
public interface IBankDAO extends JpaRepository<Bank, Long> {

//	@Query("select accNo,name from Banking_Details where accNo =?1")
//	Optional<Bank> accountsDetails(@Param("c") double accNo);
//
//	@Query("select be.bal from Bank be where be.accNo =?1")
//	Optional<Double> showBalance(@Param("c") double accno);
	
}
