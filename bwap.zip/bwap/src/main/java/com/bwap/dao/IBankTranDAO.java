package com.bwap.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.bwap.entity.Transaction;

@Repository
public interface IBankTranDAO extends JpaRepository<Transaction, Integer> {

	@Query("from Transaction where acNo=?1")
	List<Transaction> printTransaction(Long acNo);
	
	
}
