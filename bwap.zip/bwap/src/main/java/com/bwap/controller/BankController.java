package com.bwap.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.bwap.entity.Bank;
import com.bwap.entity.Transaction;
import com.bwap.service.IBankService;

import exceptionSB.BankUserIOException;

@RestController
@RequestMapping("/banking")
public class BankController {

	@ResponseStatus(value=HttpStatus.NOT_FOUND,
			reason="Acount with this id is not present")
	
	@ExceptionHandler({Exception.class})
	public void handleException() {
		   
	}
	
	@Autowired
	IBankService bankService;

	@RequestMapping(value = "/createAccount", method = RequestMethod.POST)
	public Bank addAccount(@RequestBody Bank bank) throws BankUserIOException{
		return bankService.addAccount(bank);

	}

	@GetMapping("/showDetails/{accountNo}")
	public Bank accountsDetails(@PathVariable Long accountNo)  throws BankUserIOException{
		return bankService.checkDetails(accountNo);
	}

	@GetMapping("/showBalance/{accountNo}")
	public ResponseEntity<String> showBalance(@PathVariable Long accountNo)  throws BankUserIOException{
		Long balance = bankService.showBalance(accountNo);
		return new ResponseEntity<String>("Available balance: " + balance, HttpStatus.OK);
	}

	@PutMapping("/deposit/{accountNo}/{amount}")
	public ResponseEntity<String> deposit(@PathVariable Long accountNo, @PathVariable Long amount)  throws BankUserIOException{
		long balance = bankService.depositMoney(accountNo, amount);
		return new ResponseEntity<String>("After deposited: " + balance, HttpStatus.OK);
	}

	@PutMapping("/withdraw/{accountNo}/{amount}")
	public ResponseEntity<String> withdraw(@PathVariable Long accountNo, @PathVariable Long amount) throws BankUserIOException {
		long balance = bankService.withdrawMoney(accountNo, amount);
		return new ResponseEntity<String>("After withdrawn: " + balance, HttpStatus.OK);
	}

	@PutMapping("/fundTransfer/{accountNo1}/{amount}/{accountNo2}")
	public ResponseEntity<String> fundTransfer(@PathVariable Long accountNo1, @PathVariable Long amount,
			@PathVariable Long accountNo2)  throws BankUserIOException{
		long balance = bankService.moneyTransfer(accountNo1, amount, accountNo2);
		return new ResponseEntity<String>("Amount of Rs." + amount + " Transfered successfully sent to " + accountNo2
				+ ". New balance of " + accountNo1 + " is " + balance, HttpStatus.OK);
	}

	@GetMapping("/printTrans/{accountNo}")
	public List<Transaction> printTransaction(@PathVariable long accountNo) throws BankUserIOException {
		return bankService.printTransaction(accountNo);
	}

}
