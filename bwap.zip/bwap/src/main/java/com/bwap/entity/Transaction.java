package com.bwap.entity;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="BankTransactionRep")
public class Transaction {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seqId")
	@SequenceGenerator(name = "seqId", initialValue = 1000, sequenceName = "tran_id")
	@Column(name="BankTransactionID")
	private int tranid;
	@Column(name="BankUserAccountNo")
	private Long acNo;
	@Column(name="BankUserBalance")
	private Long balance;
	@Column(name="BankUserTransactionDate")
	private LocalDate date;
	@Column(name="BankUserTransactionTime")
	private LocalTime time;	
	@Column(name="BankUserTransactionType")
	private String type;

	
	
	public Transaction( Long acNo, Long balance, LocalDate date, LocalTime time, String type) {
		super();
	
		this.acNo = acNo;
		this.balance = balance;
		this.date = date;
		this.time = time;
		this.type = type;
	}
	
	

	public Transaction() {
		super();
	}



	public int getTranid() {
		return tranid;
	}

	public void setTranid(int tranid) {
		this.tranid = tranid;
	}

	public Long getAcno() {
		return acNo;
	}

	public void setAcno(Long acNo) {
		this.acNo = acNo;
	}

	public Long getBalance() {
		return balance;
	}

	public void setBalance(Long balance) {
		this.balance = balance;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public LocalTime getTime() {
		return time;
	}

	public void setTime(LocalTime time) {
		this.time = time;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "Transaction [tranid=" + tranid + ", acno=" + acNo + ", balance=" + balance + ", date=" + date
				+ ", time=" + time + ", type=" + type + "]";
	}

}
