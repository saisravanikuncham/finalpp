package com.bwap.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="MYBankingDetails")
public class Bank {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seqId")
	@SequenceGenerator(name = "seqId", initialValue = 1000, sequenceName = "bnk_id")
	@Column(name="MyBankAccountNumber")
	private Long acNo;
	@Column(name="MyUserName")
	private String name;
	@Column(name="MyUserPhnoneNumber")
	private String number;
	@Column(name="MyUserDOB")
	private String dob;
	@Column(name="MyUserBalance")
	private Long balance;


	/**
	 * @param acNo
	 * @param name
	 * @param number
	 * @param dob
	 * @param balance
	 */
	public Bank(Long acNo, String name, String number, String dob, Long balance) {
		super();
		this.acNo = acNo;
		this.name = name;
		this.number = number;
		this.dob = dob;
		this.balance = balance;
	}



	public Bank() {
//		super();
	}



	/**
	 * @return the acNo
	 */
	public Long getAcNo() {
		return acNo;
	}

	/**
	 * @param acNo the acNo to set
	 */
	public void setAcNo(Long acNo) {
		this.acNo = acNo;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the number
	 */
	public String getNumber() {
		return number;
	}

	/**
	 * @param number the number to set
	 */
	public void setNumber(String number) {
		this.number = number;
	}

	/**
	 * @return the dob
	 */

	public String getDob() {
		return dob;
	}

	/**
	 * @param dob the dob to set
	 */

	public void setDob(String dob) {
		this.dob = dob;
	}

	/**
	 * @return the balance
	 */

	public Long getBalance() {
		return balance;
	}

	/**
	 * @param balance the balance to set
	 */

	public void setBalance(Long balance) {
		this.balance = balance;
	}



	@Override
	public String toString() {
		return "Bank [acNo=" + acNo + ", name=" + name + ", number=" + number + ", dob=" + dob + ", balance=" + balance
				+ ",  ";
	}

}
