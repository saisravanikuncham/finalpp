package com.bwap.service;

import java.util.List;

import com.bwap.entity.Bank;
import com.bwap.entity.Transaction;

import exceptionSB.BankUserIOException;

public interface IBankService {

	public Bank addAccount(Bank bank)  throws BankUserIOException;

	public Bank checkDetails(Long accountNo)  throws BankUserIOException;

	public Long showBalance(Long accountNo)  throws BankUserIOException;

	public Long depositMoney(Long accountNo, Long balance)  throws BankUserIOException;

	public Long withdrawMoney(Long accountNo, Long balance)  throws BankUserIOException;

	public Long moneyTransfer(Long accountNo1, Long balance, Long accountNo2)  throws BankUserIOException;

	public List<Transaction> printTransaction(Long accNo)  throws BankUserIOException;

}
