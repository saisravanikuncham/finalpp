package com.bwap.service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bwap.dao.IBankDAO;
import com.bwap.dao.IBankTranDAO;
import com.bwap.entity.Bank;
import com.bwap.entity.Transaction;

import exceptionSB.BankUserIOException;

@Service
public class BankServiceImpl implements IBankService {

	@Autowired
	IBankDAO bankDAO;

	@Autowired
	IBankTranDAO tranDAO;

	@Override
	public Bank addAccount(Bank bank) throws BankUserIOException {
		try {
			bankDAO.save(bank);
			long accountNo = bank.getAcNo();
			return bankDAO.findById(accountNo).get();
		} catch (Exception e) {
			throw new BankUserIOException(e.getMessage());
		}
	}

	@Override
	public Bank checkDetails(Long accountNo) throws BankUserIOException {
		try {
			return bankDAO.findById(accountNo).get();
		} catch (Exception e) {
			throw new BankUserIOException(e.getMessage());
		}
	}

	@Override
	public Long showBalance(Long accountNo) throws BankUserIOException {
		try {
			return bankDAO.findById(accountNo).get().getBalance();
		} catch (Exception e) {
			throw new BankUserIOException(e.getMessage());
		}
	}

	@Override
	public Long depositMoney(Long accountNo, Long balance) throws BankUserIOException {
		try {
			Optional<Bank> bank = bankDAO.findById(accountNo);
			if (bank.isPresent()) {
				Bank ebank = bank.get();
				ebank.setBalance(bank.get().getBalance() + balance);
				bankDAO.save(ebank);
				Transaction trans = new Transaction(accountNo, balance, LocalDate.now(), LocalTime.now(),
						"Amount of Rs:" + balance + " Deposited");
				tranDAO.save(trans);
				return showBalance(accountNo);

			} else {
				throw new BankUserIOException("Account with this id does not exist");
			}
			// return null;
		} catch (Exception e) {
			throw new BankUserIOException(e.getMessage());
		}
	}

	@Override
	public Long withdrawMoney(Long accountNo, Long balance) throws BankUserIOException {
		try {
			Optional<Bank> bank = bankDAO.findById(accountNo);
			if (bank.isPresent()) {
				Bank ebank = bank.get();
				ebank.setBalance(bank.get().getBalance() - balance);
				bankDAO.save(ebank);
				Transaction trans = new Transaction(accountNo, balance, LocalDate.now(), LocalTime.now(),
						"Amount of Rs:" + balance + " Withdrawn");
				tranDAO.save(trans);
				return showBalance(accountNo);
			} else {
				throw new BankUserIOException("Account with this id does not exist");
			}
		} catch (Exception e) {
			throw new BankUserIOException(e.getMessage());
		}

	}

	@Override
	public Long moneyTransfer(Long accountNo1, Long balance, Long accountNo2) throws BankUserIOException {
		try {
			Optional<Bank> sender = bankDAO.findById(accountNo1);
			Optional<Bank> receiver = bankDAO.findById(accountNo2);
			if (sender.isPresent() && receiver.isPresent()) {
				Bank bank1 = sender.get();
				bank1.setBalance(sender.get().getBalance() - balance);
				bankDAO.save(bank1);

				Bank bank2 = receiver.get();
				bank2.setBalance(receiver.get().getBalance() + balance);
				bankDAO.save(bank2);

				Transaction strans = new Transaction(accountNo1, balance, LocalDate.now(), LocalTime.now(),
						"Amount of Rs:" + balance + " was sent to " + bank2.getName() + "with account number "
								+ accountNo2);
				tranDAO.save(strans);

				Transaction rtrans = new Transaction(accountNo1, balance, LocalDate.now(), LocalTime.now(),
						"Amount of Rs:" + balance + " was received from " + bank1.getName() + "with account number "
								+ accountNo1);
				tranDAO.save(rtrans);
				return showBalance(accountNo1);
			} else {
				throw new BankUserIOException("Account with this id does not exist");
			}
		} catch (Exception e) {
			throw new BankUserIOException(e.getMessage());
		}
	}

	@Override
	public List<Transaction> printTransaction(Long accNo) throws BankUserIOException {
		try {
			return tranDAO.printTransaction(accNo);
		} catch (Exception e) {
			throw new BankUserIOException(e.getMessage());
		}

	}
}
