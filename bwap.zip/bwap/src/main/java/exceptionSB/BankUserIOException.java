package exceptionSB;

public class BankUserIOException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BankUserIOException()
	{
		super();
	}
	
	public BankUserIOException(String msg)
	{
		super(msg);
	}
	
}
