package com.cg.service;

import com.cg.bean.BankBean;
import com.cg.dao.BankDao;
import com.cg.dao.BankDaoI;
import com.cg.exceptions.*;

public class BankService implements BankServiceI {

	BankDaoI bankDao = new BankDao();
	BankBean bankBean = new BankBean();
	BankBean bank1 = new BankBean();

	boolean res;

	// to get the details if account exists or not and add account

	public boolean createAccount(String name, String address, long accNo, String phone, int pin, int balance)
			throws AccountAlreadyExistsException {

		BankBean bean = new BankBean();
		boolean res = false;

		if (bankDao.checkAccount(accNo) == null) {

			bean.setAccNo(accNo);
			bean.setAdd(address);
			bean.setBalance(balance);
			bean.setName(name);
			bean.setPhone(phone);
			bean.setPin(pin);
			bean.setTrans("Account Created with Balance  : " + balance + "\n");

			bankDao.setData(accNo, bean);

			res = true;
		}

		else

		{
			res = false;
			throw new AccountAlreadyExistsException();
		}
		return res;

	}

	// to show balance

	public int showBalance(long accNo) throws AccountNotFoundException {

		bankBean = bankDao.checkAccount(accNo);
		int balance = 0;
		if (bankBean == null) {
			throw new AccountNotFoundException();
		} else {
			balance = bankBean.getBalance();
		}

		return balance;
	}

	// to deposit

	public int deposit(long accNo, int deposit_amount) throws AccountNotFoundException {

		int balance = 0;
		bankBean = bankDao.checkAccount(accNo);

		if (bankBean == null) {
			throw new AccountNotFoundException();
		} else {

			balance = bankBean.setBalance(bankBean.getBalance() + deposit_amount);
			String s = bankBean.getTrans() + "Amount deposited :" + deposit_amount + "\n";
			bankBean.setTrans(s);
			bankDao.setData(accNo, bankBean);
		}

		return balance;
	}

	// to withdraw

	public int withdraw(long accNo, int withdraw_amount) throws AccountNotFoundException, LowBalanceException {

		int balance = 0;
		bankBean = bankDao.checkAccount(accNo);
		if (bankBean == null) {
			throw new AccountNotFoundException();
		} else {
			if (bankBean.getBalance() > withdraw_amount) {
				balance = bankBean.setBalance(bankBean.getBalance() - withdraw_amount);
				String s = bankBean.getTrans() + "Amount withdrawn :" + withdraw_amount + "\n";
				bankBean.setTrans(s);
			} else {
				throw new LowBalanceException();
			}
			bankDao.setData(accNo, bankBean);
		}

		return balance;
	}

	// to transfer fund

	public boolean transferfund(long accNo, long accNo1, int transfer_amount)
			throws AccountNotFoundException, LowBalanceException {

		bankBean = bankDao.checkAccount(accNo);

		if (!(bankBean == null)) {

			bank1 = bankDao.checkAccount(accNo1);

			if (!(bank1 == null))

			{

				int sender_balance = bankBean.getBalance();

				if (sender_balance > transfer_amount) {
					int reciever_balance = bank1.getBalance();

					bankBean.setBalance(sender_balance - transfer_amount);
					bank1.setBalance(reciever_balance + transfer_amount);
					String s = bankBean.getTrans() + "Transferred to  :" + accNo1 + " Amount : " + transfer_amount + "\n";
					bankBean.setTrans(s);
					String s1 = bank1.getTrans() + "Transferred from  :" + accNo + " Amount : " + transfer_amount
							+ "\n";
					bank1.setTrans(s1);
					bankDao.setData(accNo, bankBean);
					bankDao.setData(accNo1, bank1);
				} else {
					throw new LowBalanceException();
				}
			}

			else {
				throw new AccountNotFoundException();
			}
		} else {
			throw new AccountNotFoundException();
		}

		return true;
	}

	// to validateBalance

	public boolean validateBalance(long accNo, int amount) throws LowBalanceException

	{
		bankBean = bankDao.checkAccount(accNo);
		if (bankBean == null) {
			throw new LowBalanceException();
		} else {
			return true;
		}
	}

	// to set transactions

	public String setTrans(long accNo) throws AccountNotFoundException {

		bankBean = bankDao.checkAccount(accNo);
		String s;

		if (bankBean == null) {
			throw new AccountNotFoundException();
		} else {
			s = bankBean.getTrans();
		}
		return s;
	}

}
