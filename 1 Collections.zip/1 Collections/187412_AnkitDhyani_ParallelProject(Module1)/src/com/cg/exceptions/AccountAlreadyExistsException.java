package com.cg.exceptions;

public class AccountAlreadyExistsException extends Exception {

	public AccountAlreadyExistsException() {

	}

	@Override
	public String toString() {
		return "This account already exists. Please don't create duplicacy";
	}

}
