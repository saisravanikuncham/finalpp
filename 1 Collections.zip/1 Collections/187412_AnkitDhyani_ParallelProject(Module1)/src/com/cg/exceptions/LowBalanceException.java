package com.cg.exceptions;

public class LowBalanceException extends Exception {

	public LowBalanceException() {

	}

	@Override
	public String toString() {
		return "Your BAlance is Low \nCannot Do This Operation";
	}

}
