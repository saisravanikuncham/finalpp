package com.cg.bean;

public class BankBean {
	
	private String name;
	private long AccNo;
	private int PIN;
	private String add;
	private String phone;
	private int balance;

	
	public BankBean(String name2, int accNo2, int pin2, String dob2, String add2, String phone2, int bal) {
		super();
	}

	public BankBean() {
		// TODO Auto-generated constructor stub
	}
	
	
	public int getPin() {
		return PIN;
	}

	public void setPin(int PIN) {
		this.PIN = PIN;
	}

	String trans = new String();

	public String getTrans() {
		return trans;
	}

	public void setTrans(String string) {
		trans = string;
	}

	public int getBalance() {
		return balance;
	}

	public int setBalance(int balance) {
		return this.balance = balance;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone2) {
		this.phone = phone2;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getAccNo() {
		return AccNo;
	}

	public long setAccNo(long accNo2) {
		return this.AccNo = accNo2;
	}

	public String getAdd() {
		return add;
	}

	public void setAdd(String add) {
		this.add = add;
	}
	
	@Override
	public String toString() {
		return "AccountDetails: Name =" + name + "\n Account Number =" + AccNo + "\n PIN =" + PIN + "\n Address =" + add
				+ "\n Contact Number  =" + phone + "\nBalance =" + balance;
	}

}
