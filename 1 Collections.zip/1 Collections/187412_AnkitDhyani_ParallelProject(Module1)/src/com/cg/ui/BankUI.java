package com.cg.ui;

import java.util.Scanner;

import com.cg.exceptions.*;
import com.cg.service.BankService;
import com.cg.service.BankServiceI;

public class BankUI {

	static Scanner scan = new Scanner(System.in);

	public static void main(String[] args) throws AccountNotFoundException {

		// variables

		long accountNo, accountNo1;
		int withdraw_Amount, deposit_Amount = 0, transfer_Amount = 0;
		int pin;
		int amount = 0;
		int balance = 0;
		boolean result = false;
		String cont = "yes";

		BankServiceI service = new BankService();

		// To ask choice from users and perform operations
		while (cont.equalsIgnoreCase("yes")) {
			switch (menu()) {

			// to create account

			case 1:

				System.out.println("Enter your name");
				String name = scan.nextLine();
				name += scan.nextLine();

				String regexUserName = "[A-Za-z\\s]+$";
				while (!name.matches(regexUserName)) {

					System.out.println("Invalid Format");
					System.out.println("Enter your name");
					name = scan.next();
				}

				System.out.println("Enter your address ");
				String add = scan.next();
				add += scan.nextLine();

				while (!add.matches(regexUserName)) {
					System.out.println("Invalid Format");
					System.out.println("Enter your address ");
					add = scan.nextLine();

				}

				System.out.println("Enter your phone number");
				String phone = scan.next();
				String phone_format = ("[6-9][0-9]{9}");

				while (!phone.matches(phone_format)) {
					while (phone.length() < 10 || phone.length() > 10) {

						System.out.println("Phone number should be 0f 10 digits");
						System.out.println("Enter your phone number");
						phone = scan.next();
					}
					System.out.println("Phone number should start from 6");
					System.out.println("Enter your phone number");
					phone = scan.next();
				}

				accountNo = Long.parseLong(phone) - 10000;

				System.out.println("Enter PIN");
				pin = scan.nextInt();

				while (String.valueOf(pin).length() < 4 || String.valueOf(pin).length() > 4) {

					System.out.println("PIN Number should be 0f 4 digits");
					System.out.println("Again Enter PIN");
					pin = scan.nextInt();
				}

				System.out.println("Enter Balance");
				int bal = scan.nextInt();

				while (bal < 1000) {
					System.out.println("Minimum Balance should be 1000");
					System.out.println("Enter Balance");
					bal = scan.nextInt();

				}
				try {
					result = service.createAccount(name, add, accountNo, phone, pin, bal);
				} catch (AccountAlreadyExistsException e) {

					System.out.println(e);
					break;
				}

				if (result == true) {
					System.out.println("ThankYou for joining with Us --->> Account Created Successfully !!!");
					System.out.println("Account Number : " + accountNo);

				} else {

					System.out.println("Cannot Create Account");
				}

				break;

			// to show balance
			case 2:

				System.out.println("Enter Account Number");
				accountNo = scan.nextLong();

				try {
					balance = service.showBalance(accountNo);
				} catch (AccountNotFoundException e) {
					System.out.println(e);
					break;
				}

				System.out.println("Your Account Balance is :" + balance);

				break;

			// to deposit

			case 3:

				System.out.println("Enter Account Number");
				accountNo = scan.nextLong();

				System.out.println("Enter the amount to be deposited");
				deposit_Amount = scan.nextInt();

				try {
					amount = service.deposit(accountNo, deposit_Amount);

					balance = service.showBalance(accountNo);
				}

				catch (AccountNotFoundException e) {

					System.out.println(e);
					break;
				}

				System.out.println("Amount Deposited : " + deposit_Amount);
				System.out.println("Updated Balance : " + balance);

				break;

			// to withdraw

			case 4:

				System.out.println("Enter Account Number");
				accountNo = scan.nextLong();

				System.out.println("Enter Amount to withdraw");
				withdraw_Amount = scan.nextInt();

				try {
					amount = service.withdraw(accountNo, withdraw_Amount);
					result = service.validateBalance(accountNo, withdraw_Amount);
					balance = service.showBalance(accountNo);

				} catch (AccountNotFoundException e) {

					System.out.println(e);
					break;

				} catch (LowBalanceException e) {

					System.out.println(e);
					break;
				}

				System.out.println("Amount Withdrawn : " + withdraw_Amount);
				System.out.println("Updated Balance : " + balance);

				break;

			// to transfer fund

			case 5:

				int senders_balance = 0;
				int recievers_balance = 0;

				System.out.println("Enter Account Number");
				accountNo = scan.nextLong();

				System.out.println("Enter Account Number to which you want to transfer fund");
				accountNo1 = scan.nextLong();

				System.out.println("Enter amount to Transfer");
				transfer_Amount = scan.nextInt();

				try {
					result = service.validateBalance(accountNo, transfer_Amount);
					result = service.transferfund(accountNo, accountNo1, transfer_Amount);

					senders_balance = service.showBalance(accountNo);
					recievers_balance = service.showBalance(accountNo1);

				} catch (AccountNotFoundException e) {

					System.out.println(e);
					break;
				} catch (LowBalanceException e) {
					System.out.println(e);
					break;
				}

				System.out.println("Amount transferred Successfully");
				System.out.println("Updated balance for Account Number" + accountNo + " : " + senders_balance);
				System.out.println("Updated balance for Account Number" + accountNo1 + " : " + recievers_balance);

				break;

			// to show transactions
			case 6:

				String s = null;
				System.out.println("Enter Account Number");
				accountNo = scan.nextLong();
				System.out.println("Enter PIN");
				pin = scan.nextInt();
				try {
					s = service.setTrans(accountNo);
					System.out.println(s);
				} catch (AccountNotFoundException e) {
					System.out.println(e);
					break;
				}

				// to exit
			case 7:
				System.exit(0);
				cont = "no";
				break;
			default:
				System.out.println("Enter the choice between 1 - 7 ");
				menu();

			}
		}

	}

	// to display menu
	public static int menu() {

		System.out.println("------------Welcome to Dhyani Bank----------");
		System.out.println("1. Create Account-----");
		System.out.println("2. Show Balance-----");
		System.out.println("3. Deposit-----");
		System.out.println("4. Withdraw-----");
		System.out.println("5. Transer Fund-----");
		System.out.println("6. Print Transcations-----");
		System.out.println("7. Exit-----");

		System.out.println("Enter Choice-----");
		int choice = scan.nextInt();

		String s = Integer.toString(choice);
		String pattern = ("[0-7]{1}");
		while (!s.matches(pattern)) {
			System.out.println("Invalid Chice");
			System.out.println("Enter Choice");
			choice = scan.nextInt();
		}
		return choice;
	}

}
